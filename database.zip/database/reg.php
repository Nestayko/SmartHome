<?php
require "web.php";
$name=$_POST["name"];
$user_name=$_POST["user_name"];
$user_pass=$_POST["user_pass"];



$sql_query = "SELECT * FROM user_info WHERE user_name ='".$user_name."';";
$result = mysqli_query($con,$sql_query);
if(mysqli_num_rows($result)>0)
{
echo "Registration Error...Try different User name "	;	
}

else{



$sql_query="insert into user_info values('$name','$user_name','$user_pass');";
if(mysqli_query($con,$sql_query))	
{
echo "Registration Successful!"	;
	
}	
else
{
echo "Data insert error...".mysqli_error($con);
	
}
	
}	
	
?>