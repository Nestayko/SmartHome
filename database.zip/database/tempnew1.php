<?php

$db_name="Enter your database name here";
	$mysql_user="Enter your User name here";
	$mysql_pass="Enter your password here";
	$server_name="Enter your server name here";
	
	$user_name=$_POST["user_name"];
	$combined=$_POST["combined"];
	
	$sql = "select * from temp where user_name ='".$user_name."' and data ='".$combined."';";
	
	
	$con = mysqli_connect($server_name,$mysql_user,$mysql_pass,$db_name);

$result = mysqli_query($con, $sql);
$response = array();
while($row = mysqli_fetch_array($result))
{
	
array_push($response,array("name"=>$row[0],"temp"=>$row[1],"date"=>$row[3]));	
}

echo json_encode(array("server_response"=>$response));


mysqli_close($con);



	
	
	
?>