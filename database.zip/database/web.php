<?php
	$db_name="Enter your database name here";
	$mysql_user="Enter your User name here";
	$mysql_pass="Enter your password here";
	$server_name="Enter your server name here";
	
	$con = mysqli_connect($server_name,$mysql_user,$mysql_pass,$db_name);
	if(!$con)
	{
	die("Error in Database Connection".mysqli_connect_error());
		
	}
	else
	{
	//echo "<h3>Database connection Success...</h3>";
		
	}
	?>