package puretech.barrymore;

import android.content.Context;
import android.content.Intent;
import android.content.SharedPreferences;
import android.graphics.drawable.AnimationDrawable;
import android.hardware.SensorManager;
import android.media.AudioAttributes;
import android.media.AudioManager;
import android.media.Image;
import android.media.MediaPlayer;
import android.media.SoundPool;
import android.os.Bundle;
import android.os.Handler;
import android.support.v7.app.AppCompatActivity;
import android.support.v7.widget.Toolbar;
import android.view.View;
import android.view.Menu;
import android.view.MenuItem;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ImageButton;
import android.widget.ImageView;
import android.widget.Toast;

import com.squareup.seismic.ShakeDetector;

import java.util.HashMap;

public class MainActivity extends AppCompatActivity implements ShakeDetector.Listener {
Button button1,button2,click;
    final String SAVED_TEXT = "saved_one";
    final String SAVED_TEXT3 = "saved_three";
    final String SAVED_TEXT2 = "saved_two";
    boolean all;
    boolean all1;
    boolean two,three;
    boolean one;
    SharedPreferences sPref;
    EditText ET_NAME, ET_PASS;
    String login_name, login_pass;
    ImageView image,image1;
    String savedText32;
    SoundPool soundPool;
    HashMap<Integer, Integer> soundPoolMap;
    int soundID = 1;
    Button sound1;
    String savedText33;
    final Handler handler = new Handler();
    ImageButton iv ;
    AnimationDrawable anim;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);


        sPref = getPreferences(MODE_PRIVATE);
        savedText33 = sPref.getString(SAVED_TEXT3, "functionon");

        if(savedText33.equals("functionon")){

            all=true;
            //functionOn();
all1=true;
        }

        else
        {

            all=false;
            //functionOff();
            all1=false;
        }








        button1=(Button)findViewById(R.id.buttonreg);
        button2=(Button)findViewById(R.id.buttonlog);
        SensorManager sensorManager = (SensorManager) getSystemService(SENSOR_SERVICE);
        ShakeDetector sd = new ShakeDetector(this);
        sd.start(sensorManager);

        image=(ImageView)findViewById(R.id.imageView);
        image1=(ImageView)findViewById(R.id.imageViewlast);
        ET_NAME = (EditText)findViewById(R.id.user_name);
        ET_PASS = (EditText)findViewById(R.id.user_pass);

        ///////////////////////////////
        ET_NAME.setVisibility(View.GONE);
        ET_PASS.setVisibility(View.GONE);
        image.setVisibility(View.GONE);
        image1.setVisibility(View.GONE);
        button1.setVisibility(View.GONE);
        button2.setVisibility(View.GONE);

        iv = (ImageButton)findViewById(R.id.imageView1);
        anim = (AnimationDrawable)iv.getBackground();
        anim.start();
        AudioAttributes audioAttributes = new AudioAttributes.Builder()
                .setUsage(AudioAttributes.USAGE_GAME)
                .setContentType(AudioAttributes.CONTENT_TYPE_SONIFICATION)
                .build();

        soundPool = new SoundPool.Builder()
                .setMaxStreams(25)
                .setAudioAttributes(audioAttributes)
                .build();

        soundPoolMap = new HashMap<Integer, Integer>();
        soundPoolMap.put(soundID, soundPool.load(this, R.raw.beep, 1));


        AudioManager audioManager = (AudioManager)getSystemService(Context.AUDIO_SERVICE);
        float curVolume = audioManager.getStreamVolume(AudioManager.STREAM_MUSIC);
        float maxVolume = audioManager.getStreamMaxVolume(AudioManager.STREAM_MUSIC);
        float leftVolume = curVolume/maxVolume;
        float rightVolume = curVolume/maxVolume;
        int priority = 1;
        int no_loop = 1;
        float normal_playback_rate = 1f;
        soundPool.play(soundPoolMap.get(soundID), leftVolume, rightVolume, priority, no_loop, normal_playback_rate);












        handler.postDelayed(stopAnim, 6500);


    }



    public void stopitplease(View view)
    {

        anim.stop();
        iv.setVisibility(View.GONE);
        ET_NAME.setVisibility(View.VISIBLE);
        ET_PASS.setVisibility(View.VISIBLE);

        button1.setVisibility(View.VISIBLE);
        button2.setVisibility(View.VISIBLE);
        soundPool.stop(soundPoolMap.get(soundID));

        if(all1==true)
        {
            image.setVisibility(View.VISIBLE);
            image1.setVisibility(View.GONE);

        }

        if(all1==false)
        {
            image.setVisibility(View.GONE);
            image1.setVisibility(View.VISIBLE);

        }





    }










    private final Runnable stopAnim = new Runnable(){
        public void run(){

            anim.stop();
            iv.setVisibility(View.GONE);
            ET_NAME.setVisibility(View.VISIBLE);
            ET_PASS.setVisibility(View.VISIBLE);

            button1.setVisibility(View.VISIBLE);
            button2.setVisibility(View.VISIBLE);
            soundPool.stop(soundPoolMap.get(soundID));

if(all1==true)
{
    image.setVisibility(View.VISIBLE);
    image1.setVisibility(View.GONE);

}

            if(all1==false)
            {
                image.setVisibility(View.GONE);
                image1.setVisibility(View.VISIBLE);

            }





        }
    };













    public void hearShake() {
        Toast.makeText(this, "Don't shake me, bro!", Toast.LENGTH_SHORT).show();

    }


    public void userReg(View view) {
        Intent intent = new Intent(this, RegisterMe.class);
        startActivity(intent);

    }


    public void turnitoff(View view)
    {

        all=false;
        //functionOff();
        sPref = getPreferences(MODE_PRIVATE);
        SharedPreferences.Editor ed = sPref.edit();
        ed.putString(SAVED_TEXT3, "off");
        ed.commit();
        image.setVisibility(View.GONE);
        image1.setVisibility(View.VISIBLE);

    }

    public void turniton(View view)
    {

        all=true;
        //functionOn();
        sPref = getPreferences(MODE_PRIVATE);
        SharedPreferences.Editor ed = sPref.edit();
        ed.putString(SAVED_TEXT3, "functionon");
        ed.commit();
        image.setVisibility(View.VISIBLE);
        image1.setVisibility(View.GONE);

    }












    void functionCheck(){Toast.makeText(this, "check", Toast.LENGTH_SHORT).show();}

    void functionOn(){Toast.makeText(this, "Shared Preferences On", Toast.LENGTH_SHORT).show();}

    void functionOff(){Toast.makeText(this, "Shared Preferences Off", Toast.LENGTH_SHORT).show();}

    public void userLogin(View view){


        login_name=ET_NAME.getText().toString();
        login_pass=ET_PASS.getText().toString();


        if(all==true) {

            if (login_name.equals("") && login_pass.equals("")) {
                sPref = getPreferences(MODE_PRIVATE);
                String savedText = sPref.getString(SAVED_TEXT, "");
                String savedText2 = sPref.getString(SAVED_TEXT2, "");
                login_name = savedText;
                login_pass = savedText2;
                String method = "login";
                BackgroundTask backgroundTask = new BackgroundTask(MainActivity.this);
                backgroundTask.execute(method, login_name, login_pass);
            } else {


                sPref = getPreferences(MODE_PRIVATE);
                SharedPreferences.Editor ed = sPref.edit();
                ed.putString(SAVED_TEXT, login_name);
                ed.putString(SAVED_TEXT2, login_pass);
                ed.commit();


                String method = "login";
                BackgroundTask backgroundTask = new BackgroundTask(MainActivity.this);
                backgroundTask.execute(method, login_name, login_pass);

            }


        }
if(all==false)
        {

            String method = "login";
            BackgroundTask backgroundTask = new BackgroundTask(MainActivity.this);
           backgroundTask.execute(method, login_name, login_pass);
            //functionCheck();


        }





    }




}











