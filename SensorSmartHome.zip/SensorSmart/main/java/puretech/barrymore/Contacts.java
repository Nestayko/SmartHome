package puretech.barrymore;

/**
 * Created by nestaykovolodymyr on 3/30/16.
 */
public class Contacts {


    private String name,email,mobile;


    public Contacts(String email,String mobile)
    {
        //this.setName(name);
        this.setEmail(email);
        this.setMobile(mobile);

    }







    public String getEmail() {
        return email;
    }

    public void setEmail(String email) {
        this.email = email;
    }

    public String getMobile() {
        return mobile;
    }

    public void setMobile(String mobile) {
        this.mobile = mobile;
    }
}
