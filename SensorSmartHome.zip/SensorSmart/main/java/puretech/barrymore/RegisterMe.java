package puretech.barrymore;

import android.app.Activity;
import android.app.AlertDialog;
import android.content.DialogInterface;
import android.os.Bundle;
import android.support.v7.app.AppCompatActivity;
import android.view.View;
import android.widget.EditText;

/**
 * Created by nestaykovolodymyr on 3/26/16.
 */
public class RegisterMe extends Activity {


AlertDialog.Builder builder;
    EditText ET_NAME,ET_USER,ET_USER_PASS,ET_USER_PASS_CONFIRM;
    String user_name,name,user_pass,user_pass_confirm;



    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.register);


        ET_NAME = (EditText)findViewById(R.id.editTextName);
       ET_USER = (EditText)findViewById(R.id.editTextUser);
        ET_USER_PASS = (EditText)findViewById(R.id.editTextPass);
        ET_USER_PASS_CONFIRM = (EditText)findViewById(R.id.confirmPassword);
    }

public void userReg(View view){

    name=ET_NAME.getText().toString();
    user_name=ET_USER.getText().toString();
    user_pass=ET_USER_PASS.getText().toString();
    user_pass_confirm=ET_USER_PASS_CONFIRM.getText().toString();

    if(name.equals("")||user_name.equals("")||user_pass.equals("")||user_pass_confirm.equals("")){

        builder =  new AlertDialog.Builder(this);
        builder.setTitle("Error");
        builder.setMessage("Please fill all the fields");
        builder.setPositiveButton("OK", new DialogInterface.OnClickListener() {

            @Override
            public void onClick(DialogInterface dialog, int which) {
                dialog.dismiss();
            }

        });
        AlertDialog alertDialog = builder.create();
        alertDialog.show();
    }
    else if(!(user_pass.equals(user_pass_confirm))){

        builder =  new AlertDialog.Builder(this);
        builder.setTitle("Error");
        builder.setMessage("Password Confirmation failed...Try again");
        builder.setPositiveButton("OK", new DialogInterface.OnClickListener() {

            @Override
            public void onClick(DialogInterface dialog, int which) {
                dialog.dismiss();
                ET_USER_PASS.setText("");
                ET_USER_PASS_CONFIRM.setText("");
            }

        });

        AlertDialog alertDialog = builder.create();
        alertDialog.show();

    }

else {

        String method = "register";
        Backgroundnew backgroundTask = new Backgroundnew(RegisterMe.this);
        backgroundTask.execute(method,name,user_name,user_pass);
        finish();

    }

}}

