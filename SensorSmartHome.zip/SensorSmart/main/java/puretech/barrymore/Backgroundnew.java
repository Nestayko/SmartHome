package puretech.barrymore;

import android.content.Context;
import android.os.AsyncTask;
import android.util.Log;
import android.widget.Toast;

import java.io.BufferedReader;
import java.io.InputStreamReader;
import java.io.OutputStreamWriter;
import java.net.URL;
import java.net.URLConnection;
import java.net.URLEncoder;

/**
 * Created by nestaykovolodymyr on 3/27/16.
 */
public class Backgroundnew extends AsyncTask<String,Void,String>

{
    Context ctx;
    public Backgroundnew(Context ctx) {
this.ctx=ctx;

    }

    protected void onPreExecute(){

    }

    @Override
    protected String doInBackground(String... params) {

        String method = params[0];
        if(method.equals("register"))
        {
        try {


            String name = params[1];
            String user_name = params[2];
            String user_pass = params[3];

            String link = "http://YourWebSiteName/reg.php";//Change this field on path to reg.php file in your website folder
            String data = URLEncoder.encode("name", "UTF-8") + "=" + URLEncoder.encode(name, "UTF-8") + "&" +
                    URLEncoder.encode("user_name", "UTF-8") + "=" + URLEncoder.encode(user_name, "UTF-8") + "&" +
                    URLEncoder.encode("user_pass", "UTF-8") + "=" + URLEncoder.encode(user_pass, "UTF-8");


            URL url = new URL(link);
            URLConnection conn = url.openConnection();
            conn.setDoOutput(true);
            OutputStreamWriter wr = new OutputStreamWriter(conn.getOutputStream());

            wr.write(data);
            wr.flush();

            BufferedReader reader = new BufferedReader(new InputStreamReader(conn.getInputStream()));

            StringBuilder sb = new StringBuilder();
            String line = "";

            // Read Server Response
            while ((line = reader.readLine()) != null) {
                sb.append(line);
                break;
            }

            return sb.toString();
        } catch (Exception e) {
            return new String("Exception: " + e.getMessage());
        }


    }

else if(method.equals("login")){

            try {



                String user_name = params[1];
                String user_pass = params[2];

                String link = "http://YourWebSiteName/loginnew.php";//Change this field on path to loginnew.php file in your website folder

                String data = URLEncoder.encode("user_name", "UTF-8") + "=" + URLEncoder.encode(user_name, "UTF-8") + "&" +
                        URLEncoder.encode("user_pass", "UTF-8") + "=" + URLEncoder.encode(user_pass, "UTF-8");


                URL url = new URL(link);
                URLConnection conn = url.openConnection();
                conn.setDoOutput(true);
                OutputStreamWriter wr = new OutputStreamWriter(conn.getOutputStream());

                wr.write(data);
                wr.flush();

                BufferedReader reader = new BufferedReader(new InputStreamReader(conn.getInputStream()));

                StringBuilder sb = new StringBuilder();
                String line = "";

                // Read Server Response
                while ((line = reader.readLine()) != null) {
                    sb.append(line);
                    break;
                }

                return sb.toString();
            } catch (Exception e) {
                return new String("Exception: " + e.getMessage());
            }








        }
return null;

    }

    @Override
    protected void onPostExecute(String result){

        Toast.makeText(ctx,result,Toast.LENGTH_SHORT).show();

    }
}
