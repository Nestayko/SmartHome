package puretech.barrymore;

import android.app.DatePickerDialog;
import android.app.Dialog;
import android.content.Intent;
import android.os.AsyncTask;
import android.os.Bundle;
import android.support.v4.view.GestureDetectorCompat;
import android.support.v7.app.AppCompatActivity;
import android.view.GestureDetector;
import android.view.MotionEvent;
import android.view.View;
import android.widget.DatePicker;
import android.widget.ImageButton;
import android.widget.Toast;

import java.io.BufferedReader;
import java.io.BufferedWriter;
import java.io.IOException;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.io.OutputStream;
import java.io.OutputStreamWriter;
import java.net.HttpURLConnection;
import java.net.MalformedURLException;
import java.net.URL;
import java.net.URLEncoder;
import java.util.Calendar;

/**
 * Created by nestaykovolodymyr on 3/27/16.
 */
public class Temperature extends AppCompatActivity {
    String json_string;
    String user_name;
    String year_xx,month_xx,day_xx;
    String combined;
    ImageButton btn;
    int year_x,month_x,day_x;
    int year_xxx,month_xxx,day_xxx;
    static final int DIALOG_ID=0;
    private GestureDetectorCompat gestureDetectorCompat;


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.temp);
        final Calendar cal= Calendar.getInstance();
        year_xxx=cal.get(Calendar.YEAR);
        month_xxx=cal.get(Calendar.MONTH);
        int monthplusone=month_xxx+1;
        day_xxx=cal.get(Calendar.DAY_OF_MONTH);



        year_xx=String.valueOf(year_xxx);
        month_xx=String.valueOf(monthplusone);
        day_xx=String.valueOf(day_xxx);
        combined=day_xx+"."+month_xx+"."+year_xx;



        btn=(ImageButton)findViewById(R.id.imageButton);
        btn.setOnLongClickListener(new View.OnLongClickListener() {
            @Override
            public boolean onLongClick(View view) {
                showDialog(DIALOG_ID);
                return true;
            }
        });

        user_name=getIntent().getExtras().getString("messageinfo");
        //Toast.makeText(getApplicationContext(), user_name_info, Toast.LENGTH_SHORT).show();
        //new BackgroundTask().execute();

    }

    @Override
    public boolean onTouchEvent(MotionEvent event) {
        this.gestureDetectorCompat.onTouchEvent(event);
        return super.onTouchEvent(event);
    }





    @Override
    protected Dialog onCreateDialog(int id)
    {
        if(id==DIALOG_ID)
        {
            return new DatePickerDialog(this,dpickerListener,year_xxx,month_xxx,day_xxx);


        }
        else{return null;}



    }




    private DatePickerDialog.OnDateSetListener dpickerListener = new DatePickerDialog.OnDateSetListener() {
        @Override
        public void onDateSet(DatePicker view, int year, int monthOfYear, int dayOfMonth) {

            year_x=year;
            month_x=monthOfYear+1;
            day_x=dayOfMonth;
           year_xx=String.valueOf(year_x);
            month_xx=String.valueOf(month_x);
            day_xx=String.valueOf(day_x);
            combined=day_xx+"."+month_xx+"."+year_xx;
            //Toast.makeText(Bluetooth.this,day_x+"."+month_x+"."+year_x,Toast.LENGTH_LONG).show();
            Toast.makeText(Temperature.this,combined,Toast.LENGTH_LONG).show();
        }
    };







    public void parseJSON(View view)
    {
        new BackgroundTask().execute();

        doThis();





    }
    public void doThis()
    {

        if(json_string==null)
        {
            Toast.makeText(getApplicationContext(), "Get json", Toast.LENGTH_SHORT).show();



        }

        else
        {

            Intent intent = new Intent(this,DispalyListView.class);
            intent.putExtra("json_data",json_string);
            startActivity(intent);

        }



    }









    class BackgroundTask extends AsyncTask<Void,Void,String>{

        String json_url;
        String JSON_STRING;




        @Override
        protected void onPostExecute(String result) {

            //TextView textView =(TextView) findViewById(R.id.textView2);
            //textView.setText(result);
            json_string=result;


        }

        @Override
        protected void onPreExecute() {

            json_url= "http://YourWebSiteName/tempnew1.php";//Change this field on path to tempnew1.php file in your website folder




        }




        @Override
        protected String doInBackground(Void... params) {

            //year_xx=String.valueOf(year_x);
            //month_xx=String.valueOf(month_x);
            //day_xx=String.valueOf(day_x);
            //combined=day_xx+"."+month_xx+"."+year_xx;
//combined="31.3.2016";


            try {
                URL url = new URL(json_url);
                HttpURLConnection httpURLConnection = (HttpURLConnection) url.openConnection();
                httpURLConnection.setRequestMethod("POST");
                httpURLConnection.setDoOutput(true);
                httpURLConnection.setDoInput(true);
                OutputStream OS = httpURLConnection.getOutputStream();
                BufferedWriter bufferedWriter = new BufferedWriter(new OutputStreamWriter(OS,"UTF-8"));
                String data = URLEncoder.encode("user_name", "UTF-8")+ "=" + URLEncoder.encode(user_name,"UTF-8")+ "&" +
                        URLEncoder.encode("combined", "UTF-8")+ "=" + URLEncoder.encode(combined, "UTF-8");
                bufferedWriter.write(data);
                bufferedWriter.flush();
                bufferedWriter.close();
                OS.close();
                InputStream IS =httpURLConnection.getInputStream();
                BufferedReader bufferedReader = new BufferedReader(new InputStreamReader(IS));
                StringBuilder stringBuilder = new StringBuilder();


                while((JSON_STRING=bufferedReader.readLine())!=null)
                {
                    stringBuilder.append(JSON_STRING+"\n");


                }
                bufferedReader.close();
                IS.close();
                httpURLConnection.disconnect();
                //Thread.sleep(5000);
                return stringBuilder.toString().trim();

            } catch (MalformedURLException e) {
                e.printStackTrace();
            } catch (IOException e) {
                e.printStackTrace();
            }


            return null;
        }


        @Override
        protected void onProgressUpdate(Void... values) {
            super.onProgressUpdate(values);
        }





    }










}
















