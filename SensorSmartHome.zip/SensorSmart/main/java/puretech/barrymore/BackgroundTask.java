package puretech.barrymore;

import android.app.Activity;
import android.app.AlertDialog;
import android.app.ProgressDialog;
import android.content.Context;
import android.content.DialogInterface;
import android.content.Intent;
import android.os.AsyncTask;
import android.util.Log;
import android.widget.EditText;

import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

import java.io.BufferedReader;
import java.io.BufferedWriter;
import java.io.IOException;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.io.OutputStream;
import java.io.OutputStreamWriter;
import java.net.HttpURLConnection;
import java.net.MalformedURLException;
import java.net.URL;
import java.net.URLEncoder;

/**
 * Created by nestaykovolodymyr on 3/26/16.
 */
public class BackgroundTask extends AsyncTask<String,Void,String> {

String info;
    AlertDialog.Builder builder;
    AlertDialog alertDialog;
    Activity activity;
    ProgressDialog progressDialog;
    Context ctx;

    public BackgroundTask(Context ctx){

        this.ctx=ctx;
        activity=(Activity)ctx;


    }



    @Override
    protected void onPostExecute(String json) {

        try {
            progressDialog.dismiss();
            JSONObject jsonObject = new JSONObject(json);
            JSONArray jsonArray = jsonObject.getJSONArray("server_response");

            JSONObject JO =jsonArray.getJSONObject(0);
            String code = JO.getString("code");
            String message = JO.getString("message");


             if(code.equals("login_true"))
{

Intent intent = new Intent(activity,Temperature.class);
    intent.putExtra("messageinfo",info);
    activity.startActivity(intent);



}
            else if(code.equals("login_false"))
             {

                 showDialog("Error",message,code);

             }



        } catch (JSONException e) {
            e.printStackTrace();
        }


    }


    public void showDialog(String title,String message, String code){

     builder.setTitle(title);
        if(code.equals("login_false")){


            builder.setMessage(message);
builder.setPositiveButton("OK", new DialogInterface.OnClickListener() {


    @Override
    public void onClick(DialogInterface dialog, int which) {


        EditText user, userpass;
        user = (EditText) activity.findViewById(R.id.user_name);
        userpass = (EditText) activity.findViewById(R.id.user_pass);
        user.setText("");
        userpass.setText("");
        dialog.dismiss();


    }
});










        }

        AlertDialog alertDialog =builder.create();
        alertDialog.show();
    }


    @Override
    protected void onProgressUpdate(Void... values) {
        super.onProgressUpdate(values);
    }





    @Override
    protected void onPreExecute() {

        builder = new AlertDialog.Builder(activity);
progressDialog = new ProgressDialog(ctx);
        progressDialog.setTitle("Please wait");
        progressDialog.setMessage("Connecting to Server");
        progressDialog.setIndeterminate(true);
        progressDialog.setCancelable(false);
        progressDialog.show();

    }




    @Override
    protected String doInBackground(String... params) {


        String login_url = "http://YourWebSiteName/loginnew.php";//Change this field on path to loginnew.php file in your website folder

        String method=params[0];

        if (method.equals("login")) {
            String user_name = params[1];
            String user_pass = params[2];
info = user_name;
            try {
                URL url = new URL(login_url);
                HttpURLConnection httpURLConnection = (HttpURLConnection) url.openConnection();
                httpURLConnection.setRequestMethod("POST");
                httpURLConnection.setDoOutput(true);
                httpURLConnection.setDoInput(true);
                OutputStream OS = httpURLConnection.getOutputStream();
                BufferedWriter bufferedWriter = new BufferedWriter(new OutputStreamWriter(OS,"UTF-8"));
                String data = URLEncoder.encode("user_name","UTF-8")+ "=" + URLEncoder.encode(user_name,"UTF-8")+ "&" +
                        URLEncoder.encode("user_pass", "UTF-8")+ "=" + URLEncoder.encode(user_pass,"UTF-8");
                bufferedWriter.write(data);
                bufferedWriter.flush();
                bufferedWriter.close();
                OS.close();


                InputStream IS =httpURLConnection.getInputStream();
                BufferedReader bufferedReader = new BufferedReader(new InputStreamReader(IS));
                StringBuilder stringBuilder = new StringBuilder();

                String line = "";
                while((line= bufferedReader.readLine())!=null)
                {
                 stringBuilder.append(line+"\n");

                }

                //bufferedReader.close();
               // IS.close();
                httpURLConnection.disconnect();
                Thread.sleep(5000);
                Log.d("Test","Test 3 pass");
                return stringBuilder.toString().trim();

            } catch (MalformedURLException e) {
                e.printStackTrace();
            } catch (IOException e) {
                e.printStackTrace();
            } catch (InterruptedException e) {
                e.printStackTrace();
            }


        }



        return null;
    }
}
