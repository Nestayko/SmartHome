package temp;

public class temperatuurSensor {
	private double tempCelcuis;
	
	/**
	 * @return the tempCelcuis
	 */
	public double getTempCelcuis() {
		return tempCelcuis;
	}

	/**
	 * @param tempCelcuis the tempCelcuis to set
	 */
	public void setTempCelcuis(double tempCelcuis) {
		this.tempCelcuis = tempCelcuis;
	}

	public temperatuurSensor(){
		
	}
	
	
}
