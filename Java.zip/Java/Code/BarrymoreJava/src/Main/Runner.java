
package Main;
import jssc.SerialPort;
import jssc.SerialPortException;
import jssc.SerialPortList;
import controller.serialData;
import temp.temperatuurSensor;
import java.util.Scanner;
import java.util.Date;
import javafx.application.Application;
import javafx.event.ActionEvent;
import javafx.event.EventHandler;
import javafx.scene.Scene;
import javafx.scene.control.Button;
import javafx.scene.layout.StackPane;
import javafx.stage.Stage;

import javafx.geometry.Insets;
import javafx.geometry.Pos;
import javafx.scene.control.Label;
import javafx.scene.control.ProgressIndicator;
import javafx.scene.layout.GridPane;


import javafx.scene.control.TextField;
import javafx.scene.image.Image;
import javafx.scene.image.ImageView;
import javafx.scene.layout.HBox;
import javafx.scene.layout.VBox;
import javafx.scene.paint.Color;

public class Runner extends Application {
    
    Stage window;
    Scene scene1,scene2;
    
    String one,two,three;
    
    
    
    
    @Override
    public void start(Stage primaryStage) {
        window= primaryStage;
        
        String filepath = "Enter-here-link-to-any-png-that-you-want/logo.png";//Change this field
        Button btn = new Button();
        Button btn1 = new Button("Log in");
        Button btn2 = new Button("Password");
        btn.setText("Say 'Hello World'");
        
        btn.setOnAction(new EventHandler<ActionEvent>() {
            
            @Override
            public void handle(ActionEvent event) {
                System.out.println("Hello World!");
            }
        });
        
        
        
        
       GridPane grid = new GridPane();
        grid.setAlignment(Pos.CENTER);
        grid.setHgap(6);
        grid.setVgap(6);
        Insets ins = new Insets(25,25,25,25);
        grid.setPadding(ins);
       
        Label userName = new Label("User:");
        grid.add(userName, 0, 5);
        Label password = new Label("Password:");
        grid.add(password, 0, 8);
        final TextField userTextField = new TextField();
        grid.add(userTextField, 1, 5);
        TextField passfield = new TextField();
        grid.add(passfield, 1, 8);
        grid.add(btn1, 1, 10);
        
        
        btn1.setOnAction(new EventHandler<ActionEvent>() {
            
            @Override
            public void handle(ActionEvent event) {
                window.setScene(scene2);
                
         
         
         
         
         
                
                
            }
        });
        
        
        
        StackPane root = new StackPane();
        final StackPane layout1 = new StackPane();
        
        GridPane grid1 = new GridPane();
        grid1.setAlignment(Pos.CENTER);
        grid1.setHgap(10);
        grid1.setVgap(10);
        Insets ins1 = new Insets(25,25,25,25);
        grid1.setPadding(ins1);
        
        Button btnstart = new Button("SEND TEMPERATURE");
        grid1.add(btnstart, 1, 10);
        
        
        btnstart.setOnAction(new EventHandler<ActionEvent>() {
            
            @Override
            public void handle(ActionEvent event) {
                
                
                
                
                
                ProgressIndicator p1 = new ProgressIndicator();
                p1.setPrefSize(50,50);
                
                layout1.getChildren().add(p1);
                
                
             
         one = userTextField.getText();
         String total3="2016";
         Date d = new Date();
         int tdate = d.getMonth()+1;
         int datest = d.getDate();
         int year12 = d.getYear();
         int seconds=d.getSeconds();
         int minutes=d.getMinutes();
         int hours=d.getHours();
         
         String total1=String.valueOf(tdate);
         String total2=String.valueOf(datest);
         String hours1=String.valueOf(hours);
         String mins1=String.valueOf(minutes);
         String sec1=String.valueOf(seconds);
         
         String totaltime="Time"+" "+hours1+":"+mins1;
         String total4=total2+"."+total1+"."+total3;
         String data ="24.4.2016";
     String[] portNames = SerialPortList.getPortNames();
SerialPort port = null;
for(int i = 0; i < portNames.length; i++){
System.out.println(portNames[i]);
port = new SerialPort(portNames[i]);
}
serialData dataCatcher = new serialData(port, new temperatuurSensor()); 






while(true){
try{
String sValue = dataCatcher.receiveString();
double value = Double.valueOf(sValue);
                                
                               
                                JDBCExample.writeData( one,value,total4,totaltime );//if data will be recognised wrong, change total4 on data and enter it manually
                                
                                

}catch(Exception e){
System.out.println(e.getMessage());
}
}
                
                
                
                
                
               
         
         
         
         
         
                
               
            }
        });
        
        
        layout1.getChildren().addAll(grid1,btnstart);
        
       
        
        
        
        
        scene2 = new Scene(layout1,500,500);
        
        
        
        
        
        root.getChildren().add(grid);
        
        
        Scene scene = new Scene(root, 500, 500);
        
        
        
        
        primaryStage.setTitle("Barrymore");
        primaryStage.setScene(scene);
        primaryStage.show();
    }

    
    
   
     public static void main(String[] args) {
        launch(args);
    }
     
     
     private static String[] initData() {
        String[] sensor_data= new String[8];
        sensor_data[0]="hjk";
        sensor_data[1]="5";
        sensor_data[2]="lat";
        sensor_data[3]="alt";
        sensor_data[4]="20100505";
        sensor_data[5]="11:00";
        sensor_data[6]="1";
        sensor_data[7]="21.5";
        return sensor_data;
     }
     
     
     
     private static void testUpdateData() {
        int res = JDBCExample.updateData( initData() );
        printErrorInfo(res);
     }
     
     private static void printErrorInfo(int res) {
        System.out.print("Error: " + res + ": ");
        switch (res ) {
            case 0: 
                System.out.println("No errors");
                break;
            case -10:
                System.out.println("Unable to load driver");
                break;
            case -20:
                System.out.println("SQL error in writeData");
                break;
            case -30:
                System.out.println("SQL error in updateData");
                break;            
            default:
                System.out.println("Unknown error");
                break;                
        }
    }
}
