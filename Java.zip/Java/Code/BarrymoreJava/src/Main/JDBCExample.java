
package Main;

import java.sql.*;
public class JDBCExample {
public int number;

public int getnumber() {
        return number;
    }
public void setnumber(int newValue) {
        number = newValue;
    }

    private static final String HOSTNAME="Enter your host name";//Change this field
    private static final String PORTNUMBER = "33006";//Change this field
    private static final String USRNAME="Enter your username";//Change this field
    private static final String PASSWORD="Enter your password";   //Change this field 
    private static final String DBNAME = "Enter your DB name";//Change this field
    private static final String DBTABLE = "Enter your DB table";//Change this field
    private static final String userName = "Enter username that you used during registration in Android app";//Change this field
    
    public static int loadDriver() {
        try {
            Class.forName("com.mysql.jdbc.Driver");
        }
        catch (Exception E) {
            System.err.println("Unable to load driver");
            E.printStackTrace();
            return -10;
        }
        return 0;
    }   
    
    
    public static int writeData( String username,double value,String data, String totaltime ) {
        loadDriver();
        try {
            // setup DB network connection
            Connection db_connection = DriverManager.getConnection("jdbc:mysql://" + HOSTNAME + ":" + PORTNUMBER + "/" + DBNAME , USRNAME, PASSWORD);             

            // build query and execute on DB-server
            Statement stmt = db_connection.createStatement();
            String query = "INSERT INTO " + DBTABLE +"( `user_name` , `temp` , `data`, `time` )";
            
            String querynew = query + "VALUES ("
                    + "'" + (username) + "', '" + value + "', '" + data + "', '" + totaltime
                    + "')";
            stmt.executeUpdate(querynew);
            // close connection
            stmt.close();
            db_connection.close();
        }
        catch (SQLException E) {
            while (E != null) {
                //System.out.println("SQLException: " + E.getMessage());
                //System.out.println("SQLState: " + E.getSQLState());
                //System.out.println("VendorError: " + E.getErrorCode());
                E = E.getNextException();
                if (E != null) {
                    System.out.println("Next SQLException: ");
                }
            }
            return -20;
        }
        return 0;
    }

    // insert a sensor_reading record in the database
    public static int updateData( String[] sensorData ) {
        loadDriver();
        try {
            // setup DB network connection
            Connection db_connection = DriverManager.getConnection("jdbc:mysql://" + HOSTNAME + ":" + PORTNUMBER + "/" + DBNAME , USRNAME, PASSWORD);             

            // build query and execute on DB-server
            Statement stmt = db_connection.createStatement();
            stmt = db_connection.createStatement(ResultSet.TYPE_SCROLL_SENSITIVE, ResultSet.CONCUR_UPDATABLE);

            String query = "SELECT * FROM " + DBTABLE + " WHERE `u_id` = 1212121212";
            
            ResultSet rs = stmt.executeQuery(query);
            while (rs.next() ) {
                
                double reading = rs.getDouble("sensor_reading");
                rs.updateDouble("sensor_reading", reading/100);

                rs.updateString(2,"rubbish"); // or    rs.updateString("longitude","rubbish");
                
                int userID = rs.getInt("u_id");
                rs.updateInt(1 , userID-12121212 ); // or    rs.updateInt("u_id",userID-12121212);
                
                rs.updateRow();
       
            }
            // close connection
            stmt.close();
            db_connection.close();
        }
        catch (SQLException E) {
            while (E != null) {
                System.out.println("SQLException: " + E.getMessage());
                System.out.println("SQLState: " + E.getSQLState());
                System.out.println("VendorError: " + E.getErrorCode());
                E = E.getNextException();
                if (E != null) {
                    System.out.println("Next SQLException: ");
                }
            }
            return -30;
        }
        return 0;
    }    
    
    
    
}