package controller;

import java.io.UnsupportedEncodingException;

import temp.temperatuurSensor;

import jssc.SerialPort;
import jssc.SerialPortException;
import jssc.SerialPortList;

public class serialData {
	SerialPort port;
	temperatuurSensor sensor;
	
	workerThread worker;
	public serialData(SerialPort port, temperatuurSensor sensor){
		this.port = port;
		this.sensor  = sensor;
		try {
			this.port.openPort();
			this.port.setParams(9600, 8, 1, 0);
		} catch (SerialPortException e) {
			
			System.out.println(e.getMessage());
			e.printStackTrace();
		}
		
		

	}
	
	
	
	public String receiveString(){
		
		try {
			String bufferString = new String();
			Boolean keepRunning = false;
			
			while(!keepRunning){
				
				while(port.getInputBufferBytesCount()==0);; 
				byte buff[] = port.readBytes();
				bufferString = bufferString.concat(new String(buff, "UTF-8"));
				keepRunning = bufferString.contains("\r\n");
			}
			
			if(bufferString.contains("Data")){
				int start = bufferString.indexOf(":")+1; 
				int end = bufferString.indexOf("\r\n",start);
				String value = bufferString.substring(start,end);
				return value;
			}else{
				return null;
			}
				
		} catch (Exception e) {
				e.printStackTrace();
				return null;
		}
	}
	
	public void updateTemp(double value){
		sensor.setTempCelcuis(value);
		
	}
	
	
	private class workerThread extends Thread{
		
		public void run(){
			
		}
		
	}
	
	
}
